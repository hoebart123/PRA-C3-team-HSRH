# Upgrading from 1.x to 2.0

To read more about the upgrade process from Phiki 1.x to v2.0, please [visit the official upgrade guide](https://phiki.dev/upgrade-2.0) on our website.
