<?php

namespace Phiki\Exceptions;

use Exception;

class FailedToInitializePatternSearchException extends Exception
{
    //
}
