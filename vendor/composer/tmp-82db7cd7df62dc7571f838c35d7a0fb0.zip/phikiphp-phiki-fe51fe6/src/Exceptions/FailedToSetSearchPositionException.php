<?php

namespace Phiki\Exceptions;

use Exception;

class FailedToSetSearchPositionException extends Exception
{
    //
}
