<?php

namespace Phiki\Grammar\Injections;

enum Prefix: int
{
    case Left = -1;
    case Right = 1;
}
