<?php

namespace Phiki\Phast;

class Text extends Literal
{
    //
}
